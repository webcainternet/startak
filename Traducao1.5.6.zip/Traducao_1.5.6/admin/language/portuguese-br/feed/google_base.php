<?php
// Heading
$_['heading_title']		= 'Google Base';

// Text
$_['text_feed']			= 'Feeds de produtos';
$_['text_success']		= 'Base de Feed do Google atualizada com sucesso!';

// Entry
$_['entry_status']		= 'Situação:';
$_['entry_data_feed']	= 'URL do feed:';

// Error
$_['error_permission']	= 'Atenção: Você não possui permissão para modificar a base de Feed do Google!';
?>
