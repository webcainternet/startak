<?php
// Heading
$_['heading_title']		= 'Google Sitemap';

// Text 
$_['text_feed']			= 'Feeds de produtos';
$_['text_success']		= 'Feed Google Sitemap atualizado com sucesso!';

// Entry
$_['entry_status']		= 'Situação:';
$_['entry_data_feed']	= 'URL do feed:';

// Error
$_['error_permission']	= 'Atenção: Você não possui permissão para modificar o feed Google Sitemap!';
?>
