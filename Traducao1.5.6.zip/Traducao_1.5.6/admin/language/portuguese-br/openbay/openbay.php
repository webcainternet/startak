<?php 
$_['heading_title']                     = 'eBay';
$_['text_edit']                         = 'Editar';
$_['text_install']                      = 'Instalar';
$_['text_uninstall']                    = 'Desinstalar';
$_['text_enabled']                      = 'Habilitado';
$_['text_disabled']                     = 'Desabilitado';
$_['error_category_nosuggestions']      = 'Não foi possível carregar nenhuma das categorias sugeridas';
$_['lang_text_success']                 = 'As edições da extensão eBay foram salvas';