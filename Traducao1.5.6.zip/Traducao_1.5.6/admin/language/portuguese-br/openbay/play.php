<?php
$_['heading_title']         = 'Play.com (EU)';
$_['lang_heading_title']    = 'OpenBay Pro para Play.com';
/* Settings tab */