<?php
$_['lang_cancel']                           = 'Cancelar';
$_['lang_page_title']                       = 'Relatório de preços concorrentes';
$_['lang_column_name']                      = 'Nome';
$_['lang_column_dispatchto']                = 'Dispachar para';
$_['lang_column_price_uk']                  = 'Seu preço (UK)';
$_['lang_column_price_cheap_uk']            = 'Preço mais barato (UK)';
$_['lang_column_price_euro']                = 'Seu preço (Europe)';
$_['lang_column_price_cheap_euro']          = 'Preço mais barato (Europe)';
$_['lang_column_stock']                     = 'Estoque';
$_['lang_column_product_id']                = 'ID';
$_['lang_column_product_type']              = 'Tipo de ID';
$_['lang_no_data_found']                    = 'Nenhum dado de preço foi encontrado';
$_['lang_created']                          = 'Relatório criado: ';