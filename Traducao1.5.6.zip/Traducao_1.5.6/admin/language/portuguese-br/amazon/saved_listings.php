<?php
$_['lang_title']                    = 'OpenBay Pro para Amazon | Listagens salvas';
$_['lang_saved_listings']           = 'Listagens salvas';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_overview']                 = 'Visão geral Amazon';
$_['lang_btn_return']               = 'Cancelar';
$_['lang_description']              = 'Esta é a lista de produtos listados que são salvos localmente e estão prontos para serem enviados para a Amazon. Clique em Enviar para postar.';
$_['lang_actions_edit']             = 'Editar';
$_['lang_actions_remove']           = 'Remover';
$_['lang_btn_upload']               = 'Enviar';
$_['lang_name_column']              = 'Nome';
$_['lang_model_column']             = 'Modelo';
$_['lang_sku_column']               = 'SKU';
$_['lang_amazon_sku_column']        = 'SKU do item Amazon';
$_['lang_actions_column']           = 'Ação';
$_['lang_uploaded_alert']           = 'As listagens salvas foram enviadas!';
$_['lang_delete_confirm']           = 'Você tem certeza?';