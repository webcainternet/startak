<?php
$_['lang_openbay']                      = 'OpenBay Pro';
$_['lang_page_title']                   = 'OpenBay Pro para eBay';
$_['lang_ebay']                         = 'eBay';
$_['lang_heading']                      = 'Relatório de estoque';
$_['lang_btn_return']                   = 'Devolção';
$_['lang_report_label']                 = 'Relatório por email';
$_['lang_report_btn']                   = 'Requisição';
$_['lang_ajax_load_error']               = 'Desculpe, não foi possível conectar';
$_['lang_ajax_load_sent']               = 'A requisição foi enviada';
