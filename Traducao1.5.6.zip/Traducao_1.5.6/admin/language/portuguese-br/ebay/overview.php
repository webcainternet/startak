<?php
$_['lang_title']                    = 'OpenBay Pro para eBay';
$_['lang_heading']                  = 'Visão geral eBay';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_heading_settings']         = 'Configurações';
$_['lang_heading_sync']             = 'Sincronzar';
$_['lang_heading_account']          = 'Minha conta';
$_['lang_heading_links']            = 'Links dos itens';
$_['lang_heading_stock_report']     = 'Relatório de estoque';
$_['lang_heading_item_import']      = 'Importar itens';
$_['lang_heading_order_import']     = 'Importar pedidos';
$_['lang_heading_adds']             = 'Add-ons instalados';
$_['lang_heading_summary']          = 'Resumo eBay';
$_['lang_heading_profile']          = 'Perfis';
$_['lang_heading_template']         = 'Templates';
$_['lang_heading_ebayacc']          = 'Conta eBay';
$_['lang_heading_register']         = 'Registre aqui';
