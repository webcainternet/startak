<?php
$_['lang_openbay']              = 'OpenBay Pro';
$_['lang_page_title']           = 'OpenBay Pro para eBay';
$_['lang_ebay']                 = 'eBay';
$_['lang_heading']              = 'Complementos';
$_['lang_addon_desc']           = 'Complementos são módulos que são conhecidos por terem o apoio ou melhorar a usabilidade do OpenBay Pro.';
$_['lang_addon_name']           = 'Nome do complemento';
$_['lang_addon_version']        = 'Versão';
$_['lang_addon_none']           = 'Você não tem complementos instalados';
$_['lang_error_validation']     = 'Você precisa registrar para o Token de sua API e habilitar o módulo.';
$_['lang_btn_return']           = 'Retornar';

