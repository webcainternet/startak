<?php
$_['lang_openbay']                      = 'OpenBay Pro';
$_['lang_page_title']                   = 'OpenBay Pro para eBay';
$_['lang_ebay']                         = 'eBay';
$_['lang_heading']                      = 'Importação de pedido';
$_['lang_btn_return']                   = 'Retorno';
$_['lang_sync_orders']                  = 'Pedidos';
$_['lang_sync_pull_orders']             = 'Importar novos pedidos';
$_['lang_sync_pull_orders_text']        = 'Importar pedidos';
$_['lang_ajax_load_error']              = 'Desculpe, não foi possível obter uma conexão';
$_['lang_error_validation']             = 'Você precisa registrar para seu Token API, e habilitar o módulo.';
$_['lang_sync_pull_notice']             = 'Isso irá importar novos pedidos desde a ultima checagem automatizada. Se você acabou de fazer a instalação, então ele assumirá como padrão as ultimas 24 horas.';
$_['lang_ajax_orders_import']           = 'Qualquer novo pedido deve aparecer dentro de alguns minutos';