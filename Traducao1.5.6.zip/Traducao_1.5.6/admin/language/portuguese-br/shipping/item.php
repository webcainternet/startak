<?php 
// Heading
$_['heading_title']    = 'Frete por Itens';

// Text
$_['text_shipping']    = 'Formas de Envio';
$_['text_success']     = 'Módulo Frete por Itens modificado com sucesso!';

// Entry
$_['entry_cost']       = 'Custo:';
$_['entry_tax_class']  = 'Grupo de Impostos:';
$_['entry_geo_zone']   = 'Região Geográfica:';
$_['entry_status']     = 'Situação:';
$_['entry_sort_order'] = 'Ordem:';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o módulo Frete por Itens!';
?>