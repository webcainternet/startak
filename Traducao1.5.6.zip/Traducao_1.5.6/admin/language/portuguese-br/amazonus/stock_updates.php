<?php
$_['lang_title']                    = 'OpenBay Pro para Amazon | Atualizações de estoques';
$_['lang_stock_updates']            = 'Atualizações de estoques';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_overview']                 = 'Visão geral Amazon';
$_['lang_my_account']               = 'Minha conta';
$_['lang_btn_return']               = 'Cancelar';
//Table columns
$_['lang_ref']                      = 'Ref';
$_['lang_date_requested']           = 'Data do pedido';
$_['lang_date_updated']             = 'Data de atualização';
$_['lang_status']                   = 'Status';
$_['lang_sku']                      = 'SKU da Amazon';
$_['lang_stock']                    = 'Estoque';


$_['lang_empty']                    = 'Sem resultados!';
$_['lang_date_start']               = 'Data começa em:';
$_['lang_date_end']                 = 'Data termina em:';
$_['lang_filter_btn']               = 'Filtro';