<?php
$_['lang_title']                    = 'OpenBay Pro para Amazon US';
$_['lang_heading']                  = 'Visão geral Amazon US';
$_['lang_overview']                 = 'Visão geral Amazon US';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_heading_settings']         = 'Configurações';
$_['lang_heading_account']          = 'Minha conta';
$_['lang_heading_links']            = 'Links dos itens';
$_['lang_heading_register']         = 'Registrar';
$_['lang_heading_stock_updates']    = 'Atualizações de estoque';
$_['lang_heading_saved_listings']   = 'Listagens salvas';