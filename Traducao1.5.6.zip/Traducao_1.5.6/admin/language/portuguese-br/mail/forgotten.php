<?php
// Text
$_['text_subject']  = '%s - Solicitação de redefinição de senha';
$_['text_greeting'] = 'Uma nova senha foi solicitada para administralçao de %s.';
$_['text_change']   = 'Para redefinir sua senha, clique no link abaixo:';
$_['text_ip']       = 'O IP usado para fazer essa requisição foi: %s';
?>