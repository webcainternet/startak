<?php
//Heading
$_['heading_title']             = 'Transação de reembolso';

//Text
$_['text_pp_express']           = 'PayPal Express Checkout';
$_['text_current_refunds']      = 'Reembolsos já foram feitos para esta transação. O máximo de reemblso é';

//Button
$_['btn_cancel']                = 'Cancelar';
$_['btn_refund']                = 'Questão de reembolso';

//Form entry
$_['entry_transaction_id']      = 'ID da transação';
$_['entry_full_refund']         = 'Reembolso total';
$_['entry_amount']              = 'Quantidade';
$_['entry_message']             = 'Mensagem';

//Error
$_['error_partial_amt']         = 'Você deve colocar uma quantidade parcial de reembolso';
$_['error_data']                = 'Dados em falta a partir da requisição';
?>