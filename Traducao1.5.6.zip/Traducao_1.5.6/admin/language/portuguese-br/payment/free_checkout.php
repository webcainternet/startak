<?php
// Heading
$_['heading_title']		= 'Pagamento Grátis';

// Text
$_['text_payment']		= 'Pagamento';
$_['text_success']		= 'Pagamento Grátis atualizado com sucesso!';

// Entry
$_['entry_order_status']= 'Situação dos pedidos:';
$_['entry_status']		= 'Situação:';
$_['entry_sort_order']	= 'Ordenação:';

// Error
$_['error_permission']	= 'Atenção: Você não possui permissão para modificar o Frete Grátis!';
?>