<?php
// Heading
$_['heading_title']         = 'Relatório de crédito do cliente';

// Column
$_['column_customer']       = 'Nome do cliente';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Grupo do cliente';
$_['column_status']         = 'Status';
$_['column_total']          = 'Total';
$_['column_action']         = 'Atividade';

// Entry
$_['entry_date_start']      = 'Data de início:';
$_['entry_date_end']        = 'Data de finalização:';
?>