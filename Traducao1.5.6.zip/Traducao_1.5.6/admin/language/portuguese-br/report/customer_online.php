<?php
// Heading
$_['heading_title']     = 'Relatório de Clientes Online';

// Text 
$_['text_guest']        = 'Visitante';
 
// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Cliente';
$_['column_url']        = 'Ultima Página Visitada';
$_['column_referer']    = 'Origem';
$_['column_date_added'] = 'Ultimo Click';
$_['column_action']     = 'Ação';
?>