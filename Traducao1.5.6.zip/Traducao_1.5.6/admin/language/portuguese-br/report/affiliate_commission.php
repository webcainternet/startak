<?php
// Heading
$_['heading_title']     = 'Relatório de comissão dos afiliados';

// Column
$_['column_affiliate']  = 'Nome do afiliado';
$_['column_email']      = 'E-Mail';
$_['column_status']     = 'Status';
$_['column_commission'] = 'Comissão';
$_['column_orders']     = 'Número da encomenda';
$_['column_total']      = 'Total';
$_['column_action']     = 'Ação';

// Entry
$_['entry_date_start']  = 'Data de início:';
$_['entry_date_end']    = 'Data de finalização:';
?>