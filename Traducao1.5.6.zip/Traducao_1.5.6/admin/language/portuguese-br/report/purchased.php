<?php
// Heading
$_['heading_title']   = 'Relatório de produtos vendidos';

// Column
$_['column_name']     = 'Nome do produto';
$_['column_model']    = 'Modelo';
$_['column_quantity'] = 'Quantidade';
$_['column_total']    = 'Total';
?>