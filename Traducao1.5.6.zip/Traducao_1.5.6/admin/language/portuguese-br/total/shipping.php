<?php
// Heading
$_['heading_title']    = 'Frete';

// Text
$_['text_total']       = 'Total do pedido';
$_['text_success']     = 'Frete atualizado com sucesso!';

// Entry
$_['entry_estimator']  = 'Valor estimado do frete:';
$_['entry_status']     = 'Situação:';
$_['entry_sort_order'] = 'Ordem:';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o frete!';
?>