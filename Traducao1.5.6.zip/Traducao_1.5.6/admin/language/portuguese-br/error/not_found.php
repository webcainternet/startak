<?php
// Heading
$_['heading_title'] = 'Página não encontrada!';

// Text
$_['text_not_found'] = 'A página que você está procurando não pôde ser encontrada. Por favor, se o problema persistir, entre em contato conosco.';
?>