<?php
$_['lang_openbay_new']              = 'Criar nova listagem';
$_['lang_openbay_edit']             = 'Visualizar / Editar listagem';
$_['lang_openbay_fix']              = 'Arrumar erros';
$_['lang_openbay_processing']       = 'Processa';

$_['lang_amazonus_saved']           = 'Salvo (não enviado)';
$_['lang_amazon_saved']             = 'Salvo (não enviado)';
$_['lang_play_pending_new']         = 'Pendente (novo)';
$_['lang_play_pending_updated']     = 'Pendente (enviado)';
$_['lang_play_warning']             = 'Mensagens de aviso';
$_['lang_play_pending_delete']      = 'Excluir pendentes';
$_['lang_play_stock_updating']      = 'Atualização de estoque';

$_['lang_markets']                  = 'Mercados';
$_['lang_bulk_btn']                 = 'Envio em massa para eBay';

$_['lang_marketplace']              = 'Mercados';
$_['lang_status']                   = 'Status';
$_['lang_option']                   = 'Opção';