<?php
// Heading
$_['heading_title']		= 'Formas de pagamento';

// Text
$_['text_install']		= 'Instalar';
$_['text_uninstall']	= 'Desinstalar';

// Column
$_['column_name']		= 'Forma de pagamento';
$_['column_status']		= 'Situação';
$_['column_sort_order']	= 'Ordem';
$_['column_action']		= 'Ação';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar as Formas de pagamento!';
?>