<?php
// Heading 
$_['heading_title']    = 'Gerenciamento de Extenções';

// Text
$_['text_success']     = 'Sua extenção foi instalada com sucesso!';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar o Gerenciamento de Extenções!';
$_['error_upload']     = 'Upload Necessário!';
$_['error_filetype']   = 'Tipo de Arquivo Inválido!';
?>