<?php
// Heading
$_['heading_title']		= 'Feeds de produtos';

// Text
$_['text_install']		= 'Instalar';
$_['text_uninstall']	= 'Desinstalar';

// Column
$_['column_name']		= 'Nome do feed de produtos';
$_['column_status']		= 'Situação';
$_['column_action']		= 'Ação';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar os Feeds de produtos!';
?>