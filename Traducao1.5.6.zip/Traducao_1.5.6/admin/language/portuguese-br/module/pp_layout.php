<?php

// Heading
$_['heading_title'] = 'Botão PayPal Express Checkout';

$_['text_module'] = 'Módulos';
$_['text_success'] = 'Você modificou o módlo PP Layout com sucesso!';
$_['text_content_top'] = 'Conteúdo do topo';
$_['text_content_bottom'] = 'Conteúdo inferior';
$_['text_column_left'] = 'Coluna da esquerda';
$_['text_column_right'] = 'Coluna da direita';

$_['entry_layout'] = 'Layout:';
$_['entry_position'] = 'Posição:';
$_['entry_status'] = 'Status:';
$_['entry_sort_order'] = 'Ordenar pedido:';

$_['error_permission'] = 'Aviso: você não tem permissão para modificar o módulo PP Layout!';