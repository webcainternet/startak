<?php
// Heading
$_['heading_title']       = 'Conta';

// Text
$_['text_module']         = 'Módulos';
$_['text_success']        = 'Módulo conta atualizado com sucesso!';
$_['text_content_top']    = 'Conteúdo Topo';
$_['text_content_bottom'] = 'Conteúdo Rodapé';
$_['text_column_left']    = 'Coluna Esquerda';
$_['text_column_right']   = 'Coluna Direita';

// Entry
$_['entry_layout']        = 'Layout:';
$_['entry_position']      = 'Posição:';
$_['entry_status']        = 'Situação:';
$_['entry_sort_order']    = 'Ordem:';

// Error
$_['error_permission']    = 'Atenção: Você não possui permissão para modificar o módulo conta!';
?>