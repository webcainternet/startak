<?php
// Heading
$_['heading_title'] = 'Botões de pagamento Amazon';

$_['text_module'] = 'Módulos';
$_['text_success'] = 'Você modificou o layout do módulo de pagamentos Amazon com sucesso!';
$_['text_content_top'] = 'Conteúdo do topo';
$_['text_content_bottom'] = 'Conteúdo inferior';
$_['text_column_left'] = 'Coluna da esquerda';
$_['text_column_right'] = 'Coluna da direita';

$_['entry_layout'] = 'Layout:';
$_['entry_position'] = 'Posção:';
$_['entry_status'] = 'Status:';
$_['entry_sort_order'] = 'Ordenar pedido:';

$_['error_permission'] = 'Aviso: Você não tem permissão para modificar o módulo de lauout de pagamentos Amazon!';