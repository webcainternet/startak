<?php
// Text
$_['text_title']       = 'Cartão de Crédito/Débito (SagePay)';
$_['text_description'] = 'Itens no %s Pedido de número: %s';
?>