<?php
// Text
$_['text_title']       = 'Instruções para pedido em dinheiro/cheque';
$_['text_instruction'] = 'Pedido em dinheiro/cheque';
$_['text_payable']     = 'Efetuar pagamento para: ';
$_['text_address']     = 'Enviar para: ';
$_['text_payment']     = 'Seu pedido será enviado assim que confirmarmos o pagamento.';
?>