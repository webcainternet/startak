<?php
// Text
$_['text_title'] = 'Cartão de crédito ou débito PAYFLOW';
$_['text_secure_connection'] = 'Criando uma conexão segura...';

//Errors
$_['error_connection'] = "Não foi possível conectar-se ao PayPal. Por favor, contacte o administrador da loja para assistência ou escolha um método de pagamento diferente.";
?>