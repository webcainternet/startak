<?php
// Text
$_['text_title']           = 'Cartão de crédito ou débito (processo seguro por PayPal)';
$_['text_credit_card']     = 'Detalhes do cartão de crédito';
$_['text_start_date']      = '(se disponível)';
$_['text_issue']           = '(para cartões Maestro e Solo apenas)';
$_['text_wait']            = 'Aguarde!';

// Entry
$_['entry_cc_type']        = 'Tipo de cartão:';
$_['entry_cc_number']      = 'Número do cartão:';
$_['entry_cc_start_date']  = 'Válido a partir de:';
$_['entry_cc_expire_date'] = 'Válido até:';
$_['entry_cc_cvv2']        = 'Código de Segurança do Cartão (CVV2):';
$_['entry_cc_issue']       = 'Número de emissão do cartão:';
?>