<?php
// Entry
$_['text_title'] = 'Cartão de crédito/débito (Google Checkout)';
?>