<?php
// Heading 
$_['heading_title'] = 'Sair da minha conta';

// Text
$_['text_message']  = '<p>Você saiu de sua Conta de Afiliado.</p>';
$_['text_account']  = 'Conta';
$_['text_logout']   = 'Logout'; 
?>