<?php
// Heading 
$_['heading_title']  = 'Alterar Senha';

// Text
$_['text_account']   = 'Conta';
$_['text_password']  = 'Minha Senha';
$_['text_success']   = 'Sua senha foi alterada com sucesso!';

// Entry
$_['entry_password'] = 'Senha:';
$_['entry_confirm']  = 'Redigite a senha:';

// Error
$_['error_password'] = 'A senha deve ter de 4 a 20 caracteres!';
$_['error_confirm']  = 'As senhas não coincidem!';
?>