<?php
// Heading 
$_['heading_title']    = 'Monitoramento da afiliação';

// Text
$_['text_account']     = 'Conta';
$_['text_description'] = 'Para ter certeza de que você seja pago pelas indicações nós precisamos acompanhar através de um código de monitoramento na URL que se liga à nossa loja. Você pode usar as ferramentas abaixo para gerar links para %s.';
$_['text_code']        = '<b>Código de monitoramento:</b>';
$_['text_generator']   = '<b>Gerador de código de monitoramento</b><br />Digite o nome do produto que você deseja gerar link:';
$_['text_link']        = '<b>Link com código de monitoramento:</b>';
?>