<?php
// Heading 
$_['heading_title']      = 'Minhas Transações';

// Column
$_['column_date_added']  = 'Adicionado em';
$_['column_description'] = 'Descrição';
$_['column_amount']      = 'Valor (%s)';

// Text
$_['text_account']       = 'Conta';
$_['text_transaction']   = 'Minhas transações';
$_['text_balance']       = 'Meu saldo atual:';
$_['text_empty']         = 'Você ainda não tem nenhuma transação!';
?>