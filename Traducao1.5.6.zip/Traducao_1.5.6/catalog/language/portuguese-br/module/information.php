<?php
// Heading 
$_['heading_title'] = 'Informação';

// Text
$_['text_contact']  = 'Contate-nos';
$_['text_sitemap']  = 'Mapa do site';
?>