<?php
// Heading 
$_['heading_title'] = 'Destaque';

// Text
$_['text_reviews']  = 'Baseado em %s avaliações.'; 
?>