<?php
$_['heading_title'] = 'Seja bem vindo à %s';
?>