<?php
// Heading 
$_['heading_title']    = 'Afiliado';

// Text
$_['text_register']    = 'Registrar';
$_['text_login']       = 'Login';
$_['text_logout']      = 'Logout';
$_['text_forgotten']   = 'Esqueci minha senha';
$_['text_account']     = 'Minha conta';
$_['text_edit']        = 'Alterar conta';
$_['text_password']    = 'Senha';
$_['text_payment']     = 'Opções de pagamento';
$_['text_tracking']    = 'Código de afiliado';
$_['text_transaction'] = 'Transações';
?>
