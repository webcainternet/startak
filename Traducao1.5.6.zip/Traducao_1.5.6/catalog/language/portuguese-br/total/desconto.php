<?php
$_['text_desconto1'] = 'Desconto de';
$_['text_desconto2'] = 'por escolher pagar por<br>';
?>