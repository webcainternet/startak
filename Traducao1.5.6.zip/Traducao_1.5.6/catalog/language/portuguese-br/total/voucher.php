<?php
// Text

$_['text_voucher'] = 'Vale-presente(%s)';
?>