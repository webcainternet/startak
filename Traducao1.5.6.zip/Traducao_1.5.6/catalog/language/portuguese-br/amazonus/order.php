<?php

$_['paid_on_amazonus_text'] = 'Pago na Amazon US';
$_['shipping_text'] = 'Envio';
$_['shipping_tax_text'] = 'Taxa de envio';
$_['gift_wrap_text'] = 'Embrulho para presente';
$_['gift_wrap_tax_text'] = 'Taxa de embrulho para presente';
$_['sub_total_text'] = 'Sub-Total';
$_['tax_text'] = 'Taxa';
$_['total_text'] = 'Total'; 