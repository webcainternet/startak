<?php
$_['title']         = 'Relatório de link de estoque do OpenBay Pro';
$_['help']          = 'Clique aqui para suporte';