<?php
$_['lang_shipping']     = 'Envio';
$_['lang_discount']     = 'Desconto';
$_['lang_tax']          = 'Taxa';
$_['lang_subtotal']     = 'Sub-total';
$_['lang_total']        = 'Total';
