<?php
// Text
$_['text_subject']  = 'Você recebeu um Vale Presente de %s';
$_['text_greeting'] = 'Parabéns! Você acaba de receber um vale presente no valor de %s';
$_['text_from']     = 'Quem lhe enviou este Vale Presente foi %s';
$_['text_message']  = 'Junto com uma mensagem que diz:';
$_['text_redeem']   = 'Para utilizar este Vale Presente, anote o código, que é <b>%s</b> então acesse o link abaixo e faça a compra do produto que desejar! Você pode inserir o código na página do carrinho, antes desmo de finalizar a compra.';
$_['text_footer']   = 'Caso tenha alguma dúvida, responda este e-mail';
?>