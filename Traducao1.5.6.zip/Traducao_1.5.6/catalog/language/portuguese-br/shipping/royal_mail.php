<?php
// Text
$_['text_title']                 = 'Royal Mail';
$_['text_weight']                = 'Peso:';
$_['text_insurance']             = 'Segurado até o valor de:';
$_['text_1st_class_standard']    = 'Primeira Classe - Postagem normal';
$_['text_1st_class_recorded']    = 'Primeira Classe - Postagem rastreada';
$_['text_2nd_class_standard']    = 'Segunda Classe - Postagem normal';
$_['text_2nd_class_recorded']    = 'Segunda Classe - Postagem rastreada';
$_['text_special_delivery_500']  = 'Entrega Especial no Dia Seguinte (&pound;500)';
$_['text_special_delivery_1000'] = 'Entrega Especial no Dia Seguinte (&pound;1000)';
$_['text_special_delivery_2500'] = 'Entrega Especial no Dia Seguinte (&pound;2500)';
$_['text_standard_parcels']      = 'Encomenda Padrão';
$_['text_airmail']               = 'Postagem Aérea';
$_['text_international_signed']  = 'Assinatura Internacional';
$_['text_airsure']               = 'Airsure';
$_['text_surface']               = 'Surface';
?>