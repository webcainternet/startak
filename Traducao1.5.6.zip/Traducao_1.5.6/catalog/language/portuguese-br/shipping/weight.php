<?php
// Text
$_['text_title']  = 'Peso de transporte base';
$_['text_weight'] = 'Peso:'; 
?>