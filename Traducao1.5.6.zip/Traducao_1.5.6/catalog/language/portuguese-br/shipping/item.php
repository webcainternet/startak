<?php
// Text
$_['text_title']       = 'Por item';
$_['text_description'] = 'Taxa de envio por Item';
?>