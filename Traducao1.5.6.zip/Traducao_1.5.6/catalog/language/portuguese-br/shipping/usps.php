<?php
// Text
$_['text_title']  = 'Serviço Postal dos Estados Unidos';
$_['text_weight'] = 'Peso:';
$_['text_eta']    = 'Tempo Estimado:';
?>