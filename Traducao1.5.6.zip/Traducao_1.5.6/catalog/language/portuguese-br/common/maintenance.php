<?php
// Heading
$_['heading_title']    = 'Manutenção';

// Text
$_['text_maintenance'] = 'Manutenção';
$_['text_message']     = '<h1 style="text-align:center;">No momento, estamos em manutenção. <br/>Estaremos de volta o mais cedo possível. Por favor, visite-nos novamente em breve.</h1>';
?>